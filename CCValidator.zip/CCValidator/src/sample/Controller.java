package sample;

import javafx.fxml.FXML;
import javafx.scene.image.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;

public class Controller {
    private static Image checkMark = new Image("check.png");
    private static Image visaLogo = new Image("visa.png");
    private static Image mcLogo = new Image("mc.png");
    private static Image amexLogo = new Image("amex.png");
    private static Image jcbLogo = new Image("jcb.png");

    private static String cardType = "";
    private static boolean cardNumberCheck = false;
    private static boolean expDateCheck = false;
    private static boolean cvvCheck = false;
    @FXML
    private TextField cvvField;
    @FXML
    private ImageView cvv_check;

    public void keyReleased1(KeyEvent e) {
        TextField tf = (TextField) e.getTarget();
        String text = tf.getText();
        int len = text.length();

        AnchorPane ap = (AnchorPane) tf.getParent();
        ImageView cardLogo = (ImageView) ap.getChildren().get(2);
        ImageView check = (ImageView) ap.getChildren().get(3);
        String cvv = cvvField.getText();

        if (len >= 1) {
            int i = 0;
            for (int j = 0; j < len; j++) {
                if (text.charAt(j) != ' ') {
                    i = j;
                    break;
                }
            }

            if (text.charAt(i) == '3') {
                if (len > i + 1) {
                    if (text.charAt(i+1) == '5') {
                        if (!cardType.equals("jcb")) {
                            if (cardType.equals("")) {
                                tf.replaceText(0, len, "                     " + text);
                            }
                            cardLogo.setImage(jcbLogo);
                            cardType = "jcb";
                        }
                    }
                    else if (text.charAt(i+1) == '4' || text.charAt(i+1) == '7') {
                        if (!cardType.equals("amex")) {
                            if (cardType.equals("")) {
                                tf.replaceText(0, len, "                     " + text);
                            }
                            cardLogo.setImage(amexLogo);
                            cardType = "amex";
                        }
                    }
                    else {
                        if (!(cardType.equals(""))) {
                            cardLogo.setImage(null);
                            cardType = "";
                            tf.replaceText(0,len,text.substring(i));
                        }
                    }
                }
                else {
                    if (!(cardType.equals(""))) {
                        cardLogo.setImage(null);
                        cardType = "";
                        tf.replaceText(0,len,text.substring(i));
                    }
                }
            }
            else if (text.charAt(i) == '4') {
                if (!cardType.equals("visa")) {
                    if (cardType.equals("")) {
                        tf.replaceText(0, len, "                     " + text);
                    }
                    cardLogo.setImage(visaLogo);
                    cardType = "visa";
                }
            }
            else if (text.charAt(i) == '5') {
                if (!cardType.equals("mc")) {
                    if (cardType.equals("")) {
                        tf.replaceText(0, len, "                     " + text);
                    }
                    cardLogo.setImage(mcLogo);
                    cardType = "mc";
                }
            }
            else {
                if (!(cardType.equals(""))) {
                    cardLogo.setImage(null);
                    cardType = "";
                    if (text.charAt(i) == ' ') {
                        tf.replaceText(0,len,"");
                    }
                    else {
                        tf.replaceText(0, len, text.substring(i));
                    }
                }
            }
        }
        else {
            if (!(cardType.equals(""))) {
                cardLogo.setImage(null);
                cardType = "";
            }
        }

        if (!(cardType.equals("")) && text.matches(" *[0-9]{4} *[0-9]{4} *[0-9]{4} *[0-9]{4}")) {
            if (!cardNumberCheck) {
                check.setImage(checkMark);
                cardNumberCheck = true;
            }
        }
        else {
            if (cardNumberCheck) {
                check.setImage(null);
                cardNumberCheck = false;
            }
        }

        if (cardType.equals("amex")) {
            if (cvv.matches("[0-9]{4}")) {
                if (!cvvCheck) {
                    cvv_check.setImage(checkMark);
                    cvvCheck = true;
                }
            }
            else {
                if (cvvCheck) {
                    cvv_check.setImage(null);
                    cvvCheck = false;
                }
            }
            cvvField.setPromptText("XXXX");
        }
        else if (!cardType.equals("")) {
            if (cvv.matches("[0-9]{3}")) {
                if (!cvvCheck) {
                    cvv_check.setImage(checkMark);
                    cvvCheck = true;
                }
            }
            else {
                if (cvvCheck) {
                    cvv_check.setImage(null);
                    cvvCheck = false;
                }
            }
            cvvField.setPromptText("XXX");
        }
        else {
            if (cvvCheck) {
                cvv_check.setImage(null);
                cvvCheck = false;
            }
            cvvField.setPromptText("XXX(X)");
        }
    }

    public void keyReleased2(KeyEvent e) {
        TextField tf = (TextField) e.getTarget();
        String text = tf.getText();

        AnchorPane ap = (AnchorPane) tf.getParent();
        ImageView check = (ImageView) ap.getChildren().get(2);

        if (text.matches("(0[1-9]|1[0-2])/[0-9]{4}")) {
            int month = (text.charAt(0) - '0')*10 + (text.charAt(1) - '0');
            int year = (text.charAt(3) - '0')*1000 + (text.charAt(4) - '0')*100 +
                    (text.charAt(5) - '0')*10 + (text.charAt(6) - '0');

            if ((year == 2021 && month >= 5) || year > 2021) {
                if (!expDateCheck) {
                    check.setImage(checkMark);
                    expDateCheck = true;
                }
            }
            else {
                if (expDateCheck) {
                    check.setImage(null);
                    expDateCheck = false;
                }
            }
        }
        else {
            if (expDateCheck) {
                check.setImage(null);
                expDateCheck = false;
            }
        }
    }

    public void keyReleased3(KeyEvent e) {
        TextField tf = (TextField) e.getTarget();
        String text = tf.getText();

        AnchorPane ap = (AnchorPane) tf.getParent();
        ImageView check = (ImageView) ap.getChildren().get(2);

        if (cardType.equals("amex")) {
            if (text.matches("[0-9]{4}")) {
                if (!cvvCheck) {
                    check.setImage(checkMark);
                    cvvCheck = true;
                }
            }
            else {
                if (cvvCheck) {
                    check.setImage(null);
                    cvvCheck = false;
                }
            }
        }
        else if (!cardType.equals("")) {
            if (text.matches("[0-9]{3}")) {
                if (!cvvCheck) {
                    check.setImage(checkMark);
                    cvvCheck = true;
                }
            }
            else {
                if (cvvCheck) {
                    check.setImage(null);
                    cvvCheck = false;
                }
            }
        }
        else {
            if (cvvCheck) {
                check.setImage(null);
                cvvCheck = false;
            }
        }
    }
}
